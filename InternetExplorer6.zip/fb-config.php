<?php
$params = [
  'app_id' => '1243708912310934',
  'app_secret' => 'd02f05d815d795f1b59f678a069d89da',
  'default_graph_version' => 'v2.2',
  ];
session_start();
require_once __DIR__ . '/facebook-php-sdk-v4-5.0.0/src/Facebook/autoload.php';
?>